# Tele-Law Case Registration Analysis Project
## Project Title: Analyzing Demographic and Regional Disparities in Tele-Law Case Registrations for Inclusive Legal Access


```python

import pandas as pd
import types
from botocore.client import Config
import ibm_boto3


def __iter__(self): return 0

#  Connecting to IBM Cloud Object Storage

cos_client = ibm_boto3.client(service_name='s3',
    ibm_api_key_id='rru08-rFUtCwUuxG0QBQ86fIsyN0XcuS51qbmgDTYm2u',
    ibm_auth_endpoint="https://iam.cloud.ibm.com/identity/token",
    config=Config(signature_version='oauth'),
    endpoint_url='https://s3.direct.au-syd.cloud-object-storage.appdomain.cloud')

bucket = 'telelawanalysis-donotdelete-pr-ibzih3ymapcblt'
object_key = 'DistrictswiseCR_AEdataf_24-25.csv'

body = cos_client.get_object(Bucket=bucket,Key=object_key)['Body']

# it is to make the file readable for pandas
if not hasattr(body, "__iter__"): 
    body.__iter__ = types.MethodType( __iter__, body )
    
telelaw_df = pd.read_csv(body)
telelaw_df.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Category</th>
      <th>States/UT's</th>
      <th>Districts</th>
      <th>No. of CSCs</th>
      <th>Female</th>
      <th>Male</th>
      <th>Total</th>
      <th>General</th>
      <th>OBC</th>
      <th>SC</th>
      <th>ST</th>
      <th>Total.1</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Case Registered</td>
      <td>Andaman and Nicobar</td>
      <td>Nicobar</td>
      <td>5</td>
      <td>615</td>
      <td>852</td>
      <td>1467</td>
      <td>557</td>
      <td>315</td>
      <td>546</td>
      <td>49</td>
      <td>1467</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Case Registered</td>
      <td>Andaman and Nicobar</td>
      <td>North and Middle Andaman</td>
      <td>37</td>
      <td>765</td>
      <td>1114</td>
      <td>1879</td>
      <td>199</td>
      <td>187</td>
      <td>1436</td>
      <td>57</td>
      <td>1879</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Case Registered</td>
      <td>Andaman and Nicobar</td>
      <td>South Andaman</td>
      <td>31</td>
      <td>340</td>
      <td>251</td>
      <td>591</td>
      <td>42</td>
      <td>89</td>
      <td>430</td>
      <td>30</td>
      <td>591</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Case Registered</td>
      <td>Andhra Pradesh</td>
      <td>Alluri Sitharama Raju</td>
      <td>430</td>
      <td>6370</td>
      <td>6828</td>
      <td>13198</td>
      <td>3585</td>
      <td>4660</td>
      <td>3176</td>
      <td>1777</td>
      <td>13198</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Case Registered</td>
      <td>Andhra Pradesh</td>
      <td>Anakapalli</td>
      <td>646</td>
      <td>6311</td>
      <td>6267</td>
      <td>12578</td>
      <td>3532</td>
      <td>4196</td>
      <td>4347</td>
      <td>503</td>
      <td>12578</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Case Registered</td>
      <td>Andhra Pradesh</td>
      <td>Anantapur</td>
      <td>577</td>
      <td>10050</td>
      <td>21628</td>
      <td>31678</td>
      <td>9189</td>
      <td>8651</td>
      <td>12245</td>
      <td>1593</td>
      <td>31678</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Case Registered</td>
      <td>Andhra Pradesh</td>
      <td>Annamayya</td>
      <td>501</td>
      <td>2039</td>
      <td>1181</td>
      <td>3220</td>
      <td>1173</td>
      <td>776</td>
      <td>1118</td>
      <td>153</td>
      <td>3220</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Case Registered</td>
      <td>Andhra Pradesh</td>
      <td>Bapatla</td>
      <td>461</td>
      <td>1756</td>
      <td>1960</td>
      <td>3716</td>
      <td>1729</td>
      <td>680</td>
      <td>1120</td>
      <td>187</td>
      <td>3716</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Case Registered</td>
      <td>Andhra Pradesh</td>
      <td>Chittoor</td>
      <td>724</td>
      <td>24254</td>
      <td>12256</td>
      <td>36510</td>
      <td>19944</td>
      <td>8818</td>
      <td>7115</td>
      <td>633</td>
      <td>36510</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Case Registered</td>
      <td>Andhra Pradesh</td>
      <td>East Godavari</td>
      <td>300</td>
      <td>5908</td>
      <td>7332</td>
      <td>13240</td>
      <td>7032</td>
      <td>3230</td>
      <td>2370</td>
      <td>608</td>
      <td>13240</td>
    </tr>
  </tbody>
</table>
</div>




```python
import pandas as pd
import ibm_boto3
from ibm_botocore.client import Config

cos_client = ibm_boto3.client(service_name='s3',
                             ibm_api_key_id='rru08-rFUtCwUuxG0QBQ86fIsyN0XcuS51qbmgDTYm2u',
                             ibm_auth_endpoint='https://iam.cloud.ibm.com/identity/token',
                             config=Config(signature_version='oauth'),
                             endpoint_url='https://s3.direct.au-syd.cloud-object-storage.appdomain.cloud')

bucket = 'telelawanalysis-donotdelete-pr-ibzih3ymapcblt'
file_name = 'DistrictswiseCR_AEdataf_24-25.csv'
obj = cos_client.get_object(Bucket=bucket, Key=file_name)['Body']
telelaw_df = pd.read_csv(obj)
print(telelaw_df.head())
```

              Category          States/UT's                 Districts  \
    0  Case Registered  Andaman and Nicobar                   Nicobar   
    1  Case Registered  Andaman and Nicobar  North and Middle Andaman   
    2  Case Registered  Andaman and Nicobar             South Andaman   
    3  Case Registered       Andhra Pradesh     Alluri Sitharama Raju   
    4  Case Registered       Andhra Pradesh                Anakapalli   
    
       No. of CSCs  Female  Male  Total  General   OBC    SC    ST  Total.1  
    0            5     615   852   1467      557   315   546    49     1467  
    1           37     765  1114   1879      199   187  1436    57     1879  
    2           31     340   251    591       42    89   430    30      591  
    3          430    6370  6828  13198     3585  4660  3176  1777    13198  
    4          646    6311  6267  12578     3532  4196  4347   503    12578  



```python
import pandas as pd
import ibm_boto3
from ibm_botocore.client import Config

# Provided credentials
cos_client = ibm_boto3.client(service_name='s3',
                              ibm_api_key_id='rru08-rFUtCwUuxG0QBQ86fIsyN0XcuS51qbmgDTYm2u',
                              ibm_auth_endpoint='https://iam.cloud.ibm.com/identity/token',
                              config=Config(signature_version='oauth'),
                              endpoint_url='https://s3.direct.au-syd.cloud-object-storage.appdomain.cloud')

bucket = 'telelawanalysis-donotdelete-pr-ibzih3ymapcblt'
file_name = 'DistrictswiseCR_AEdataf_24-25.csv'
obj = cos_client.get_object(Bucket=bucket, Key=file_name)['Body']
telelaw_df = pd.read_csv(obj)

# Verify the data
print(telelaw_df.head())
print(telelaw_df.columns)
```

              Category          States/UT's                 Districts  \
    0  Case Registered  Andaman and Nicobar                   Nicobar   
    1  Case Registered  Andaman and Nicobar  North and Middle Andaman   
    2  Case Registered  Andaman and Nicobar             South Andaman   
    3  Case Registered       Andhra Pradesh     Alluri Sitharama Raju   
    4  Case Registered       Andhra Pradesh                Anakapalli   
    
       No. of CSCs  Female  Male  Total  General   OBC    SC    ST  Total.1  
    0            5     615   852   1467      557   315   546    49     1467  
    1           37     765  1114   1879      199   187  1436    57     1879  
    2           31     340   251    591       42    89   430    30      591  
    3          430    6370  6828  13198     3585  4660  3176  1777    13198  
    4          646    6311  6267  12578     3532  4196  4347   503    12578  
    Index(['Category', 'States/UT's', 'Districts', 'No. of CSCs', 'Female', 'Male',
           'Total', 'General', 'OBC', 'SC', 'ST', 'Total.1'],
          dtype='object')



```python
# Calculate total registrations by gender
gender_total = {'Female': telelaw_df['Female'].sum(), 'Male': telelaw_df['Male'].sum()}
print("Gender-wise Total Registrations:")
print(gender_total)
```

    Gender-wise Total Registrations:
    {'Female': 15956220, 'Male': 24862532}



```python
import matplotlib.pyplot as plt

gender_total = telelaw_df[['Female', 'Male']].sum()

plt.figure(figsize=(8, 8))
plt.pie(gender_total, labels=gender_total.index, autopct='%1.1f%%', colors=['#FF1111', '#66B2FF'], startangle=90)
plt.title('Gender Wise Distribution of Tele- Law Registrations', fontsize=17)
plt.ylabel('') # Hides the 'Female' label on the side
plt.show()
```


    
![png](output_5_0.png)
    



## Gender-wise Disparity Analysis

### Objective -
This task aims to examine gender differences in the use of Tele-Law services across India. This is part of a larger effort to assess inclusivity and improve service delivery. The analysis uses data from the Tele-Law case registration dataset for the fiscal years 2021-22 to 2024-25.

### Methodology
- **Data Source**: District-wise Tele-Law case registration and advice-enabled data, sourced from https://www.data.gov.in/resource/district-wise-tele-law-case-registration-and-advice-enabled-data-fy-2021-22-2024-25.

### Results
- **Total Registrations by Gender**:
  - Female:1,59,56,220
  - Male:2,48,62,532
- **Disparity**: Male registrations exceed female registrations by 12,906,312.

### Interpretation
The significant difference between male and female registrations suggests possible gender-related barriers to accessing Tele-Law services. This may be due to factors like lower awareness, cultural restrictions, or limited outreach in areas with more women.

## ___________________________________________________________________________________________________________________________________________________________________


```python
# total registrations by caste
caste_disparity = telelaw_df[['General', 'OBC', 'SC', 'ST']].sum()
print("Caste-wise Total Registrations:")
print(caste_disparity)
```

    Caste-wise Total Registrations:
    General     9479618
    OBC        12931124
    SC         12921364
    ST          5486646
    dtype: int64



```python
import matplotlib.pyplot as plt
caste_data = telelaw_df[['General', 'OBC', 'SC', 'ST']].sum()
caste_data.plot(kind='bar', color=['#FFCC99', '#99FF99', '#CC99FF', '#9999FF'])
plt.title('Caste-wise Tele-Law Registrations')
plt.xlabel('Caste Category')
plt.ylabel('Total Registrations')
plt.show()
```


    
![png](output_8_0.png)
    


## Caste-wise Disparity Analysis

### Objective
This task looks at the differences in how various castes use Tele-Law services across India.
It focuses on the representation of marginalized groups, includingScheduled Castes(SC), Scheduled Tribes(ST), and Other Backward Classes (OBC), in comparison to the General category. 
The aim is to evaluate inclusivity and find areas where service delivery can be better.

### Methodology
- **Data Source**: District-wise Tele-Law case registration and advice-enabled data, sourced from https://www.data.gov.in/resource/district-wise-tele-law-case-registration-and-advice-enabled-data-fy-2021-22-2024-25.
- **Technology**: IBM Cloud Lite services and Python libraries (pandas, ibm-boto3, matplotlib).
- **Approach**: The dataset was loaded from IBM Cloud Object Storage, and total registrations were aggregated by caste using the 'General', 'OBC', 'SC', and 'ST' columns.

### Results
 **Total Registrations by Caste**:
  -  General: 94,79,618
  -  OBC: 1,29,31,124
  -  SC: 1,29,21,364
  -  ST: 54,86,646

### Interpretation
The analysis shows that OBC has the highest registrations at 1,29,31,124 followed closely by SC at 1,29,21,364.
General has 94,79,618 registrations, while ST has the lowest at 54,86,646.
The lower registration for ST compared to other groups may point to barriers like limited awareness, geographic isolation, or insufficient CSC coverage in tribal areas. 
The similar totals for OBC and SC suggest that access is fairly balanced within these marginalized groups, 
though both groups have more registrations than General, which could indicate targeted outreach efforts.
## ___________________________________________________________________________________________________________________________________________________________________


```python
import pandas as pd
import ibm_boto3
from ibm_botocore.client import Config

# IBM Cloud credentials
cos_client = ibm_boto3.client(service_name='s3',
                              ibm_api_key_id='rru08-rFUtCwUuxG0QBQ86fIsyN0XcuS51qbmgDTYm2u',
                              ibm_auth_endpoint='https://iam.cloud.ibm.com/identity/token',
                              config=Config(signature_version='oauth'),
                              endpoint_url='https://s3.direct.au-syd.cloud-object-storage.appdomain.cloud')

bucket = 'telelawanalysis-donotdelete-pr-ibzih3ymapcblt'
file_name = 'DistrictswiseCR_AEdataf_24-25.csv'
obj = cos_client.get_object(Bucket=bucket, Key=file_name)['Body']
telelaw_df = pd.read_csv(obj)

# Remove duplicates based on Districts and States/UTs
telelaw_df = telelaw_df.drop_duplicates(subset=['Districts', 'States/UT\'s'])


```


```python
# State/UT-wise analysis
state_disparity = telelaw_df.groupby('States/UT\'s')['Total'].sum().sort_values(ascending=False)
print("Top 10 States/UTs by Total Registrations:")
print(state_disparity.head(10))
```

    Top 10 States/UTs by Total Registrations:
    States/UT's
    Total (36 States/UT's)    10262591
    Uttar Pradesh              1850750
    Madhya Pradesh             1083427
    Maharashtra                 799196
    Jammu and Kashmir           654383
    Rajasthan                   649493
    Bihar                       554909
    Chhattisgarh                501152
    Jharkhand                   468385
    Gujarat                     432870
    Name: Total, dtype: int64



```python
# District-wise analysis
district_disparity = telelaw_df.groupby('Districts')['Total'].sum().sort_values()
print("Bottom 10 Districts by Total Registrations:")
print(district_disparity.head(10))
```

    Bottom 10 Districts by Total Registrations:
    Districts
    SarangarhBilaigarh            0
    Pandhurna                     0
    Kangpokpi                     0
    KhairgarhChhuikhadanGandai    0
    Lower Siang                   0
    Maihar                        0
    Shi Yomi                      0
    Chumoukedima                  0
    Kamle                         0
    Shamator                      0
    Name: Total, dtype: int64



```python
#Normalize by CSC count
telelaw_df['Registrations_per_CSC'] = telelaw_df['Total'] / telelaw_df['No. of CSCs']
state_normalized = telelaw_df.groupby('States/UT\'s')['Registrations_per_CSC'].mean().sort_values(ascending=False)
print("Top 10 States/UTs by Registrations per CSC:")
print(state_normalized.head(10))
```

    Top 10 States/UTs by Registrations per CSC:
    States/UT's
    Delhi                                   950.727273
    Chandigarh                              510.583333
    Dadra and Nagar Haveli & Daman & Diu    487.000000
    Lakshadweep                             261.400000
    Dadra And Nagar Haveli & Daman & Diu    185.548485
    Jammu and Kashmir                       160.179697
    Andaman and Nicobar                     121.082767
    Assam                                   108.277441
    Jharkhand                               103.179872
    Tripura                                  80.164737
    Name: Registrations_per_CSC, dtype: float64



```python
# Filter districts with zero registrations
zero_districts = telelaw_df[telelaw_df['Total'] == 0]
print(zero_districts[['Districts', 'States/UT\'s', 'Total', 'No. of CSCs']])

```

                              Districts        States/UT's  Total  No. of CSCs
    34                            Kamle  Arunachal Pradesh      0           57
    41                      Lower Siang  Arunachal Pradesh      0           51
    44                     PakkeKessang  Arunachal Pradesh      0           28
    46                         Shi Yomi  Arunachal Pradesh      0           34
    47                            Siang  Arunachal Pradesh      0           78
    156      KhairgarhChhuikhadanGandai       Chhattisgarh      0            1
    157  ManendragarhChirimiriBharatpur       Chhattisgarh      0            1
    158       MohlaManpurAmbagarhChouki       Chhattisgarh      0            1
    160              SarangarhBilaigarh       Chhattisgarh      0            1
    389                          Maihar     Madhya Pradesh      0            1
    390                       Pandhurna     Madhya Pradesh      0            1
    434                         Kamjong            Manipur      0            4
    435                       Kangpokpi            Manipur      0            2
    436                           Noney            Manipur      0            1
    437                        Pherzawl            Manipur      0            1
    440                      Tengnoupal            Manipur      0            1
    478                    Chumoukedima           Nagaland      0            1
    479                         Niuland           Nagaland      0            1
    480                        Shamator           Nagaland      0            1
    481                        Tseminyu           Nagaland      0            1
    577                            Dudu          Rajasthan      0            1
    586                         Sanchor          Rajasthan      0            1



```python
# State wise Analysis
state_disparity = telelaw_df.groupby('States/UT\'s')['Total'].sum().sort_values(ascending=False)
print("Top 10 States/UTs by Total Registrations:")
print(state_disparity.head(10))

# Districtwise Analysis
district_disparity = telelaw_df.groupby('Districts')['Total'].sum().sort_values()
print("Bottom 10 Districts by Total Registrations:")
print(district_disparity.head(10))

# Normalizing by CSC count
telelaw_df['Registrations_per_CSC'] = telelaw_df['Total']/telelaw_df['No. of CSCs']
state_normalized = telelaw_df.groupby('States/UT\'s')['Registrations_per_CSC'].mean().sort_values(ascending=False)
print("Top 10 States/UTs by Registrations per CSC:")
print(state_normalized.head(10))
```

    Top 10 States/UTs by Total Registrations:
    States/UT's
    Total (36 States/UT's)    10262591
    Uttar Pradesh              1850750
    Madhya Pradesh             1083427
    Maharashtra                 799196
    Jammu and Kashmir           654383
    Rajasthan                   649493
    Bihar                       554909
    Chhattisgarh                501152
    Jharkhand                   468385
    Gujarat                     432870
    Name: Total, dtype: int64
    Bottom 10 Districts by Total Registrations:
    Districts
    SarangarhBilaigarh            0
    Pandhurna                     0
    Kangpokpi                     0
    KhairgarhChhuikhadanGandai    0
    Lower Siang                   0
    Maihar                        0
    Shi Yomi                      0
    Chumoukedima                  0
    Kamle                         0
    Shamator                      0
    Name: Total, dtype: int64
    Top 10 States/UTs by Registrations per CSC:
    States/UT's
    Delhi                                   950.727273
    Chandigarh                              510.583333
    Dadra and Nagar Haveli & Daman & Diu    487.000000
    Lakshadweep                             261.400000
    Dadra And Nagar Haveli & Daman & Diu    185.548485
    Jammu and Kashmir                       160.179697
    Andaman and Nicobar                     121.082767
    Assam                                   108.277441
    Jharkhand                               103.179872
    Tripura                                  80.164737
    Name: Registrations_per_CSC, dtype: float64



```python
# Filter districts with zero registrations
zero_districts = telelaw_df[telelaw_df['Total'] == 0]
print("Districts with Zero Registrations after Deduplication:")
print(zero_districts[['Districts', 'States/UT\'s', 'Total', 'No. of CSCs']])
print("CSC Counts for Zero Districts:")
print(zero_districts['No. of CSCs'].value_counts())
```

    Districts with Zero Registrations after Deduplication:
                              Districts        States/UT's  Total  No. of CSCs
    34                            Kamle  Arunachal Pradesh      0           57
    41                      Lower Siang  Arunachal Pradesh      0           51
    44                     PakkeKessang  Arunachal Pradesh      0           28
    46                         Shi Yomi  Arunachal Pradesh      0           34
    47                            Siang  Arunachal Pradesh      0           78
    156      KhairgarhChhuikhadanGandai       Chhattisgarh      0            1
    157  ManendragarhChirimiriBharatpur       Chhattisgarh      0            1
    158       MohlaManpurAmbagarhChouki       Chhattisgarh      0            1
    160              SarangarhBilaigarh       Chhattisgarh      0            1
    389                          Maihar     Madhya Pradesh      0            1
    390                       Pandhurna     Madhya Pradesh      0            1
    434                         Kamjong            Manipur      0            4
    435                       Kangpokpi            Manipur      0            2
    436                           Noney            Manipur      0            1
    437                        Pherzawl            Manipur      0            1
    440                      Tengnoupal            Manipur      0            1
    478                    Chumoukedima           Nagaland      0            1
    479                         Niuland           Nagaland      0            1
    480                        Shamator           Nagaland      0            1
    481                        Tseminyu           Nagaland      0            1
    577                            Dudu          Rajasthan      0            1
    586                         Sanchor          Rajasthan      0            1
    CSC Counts for Zero Districts:
    No. of CSCs
    1     15
    57     1
    28     1
    51     1
    34     1
    78     1
    4      1
    2      1
    Name: count, dtype: int64



```python
import matplotlib.pyplot as plt
import seaborn as sns
telelaw_df.rename(columns={"States/UT's": 'State_UT'}, inplace=True)
state_totals = telelaw_df.groupby('State_UT')['Total'].sum()

top_states = state_totals.nlargest(10)


top_states.plot(kind='bar', color='#00ffee', figsize=(10, 6))
plt.title('Top 10 States/UTs by Total Tele-Law Registrations', fontsize=14)
plt.xlabel('States/UTs')
plt.ylabel('Total Registrations (in millions)')
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()



# District-wise bar chart
plt.figure(figsize=(10, 6))
district_disparity.head(10).plot(kind='bar', color='#66B2FF')
plt.title('Bottom 10 Districts by Total Tele-Law Registrations')
plt.xlabel('Districts')
plt.ylabel('Total Registrations')
plt.xticks(rotation=90, ha='right')
plt.tight_layout()
plt.show()
state_totals = telelaw_df.groupby('State_UT')['Total'].sum()
# the heatmap
if "Total (36 States/UT's)" in state_totals.index:
    state_totals.drop("Total (36 States/UT's)", inplace=True)


top_15_states_index = state_totals.nlargest(15).index
caste_by_state = telelaw_df.groupby('State_UT')[['General', 'OBC', 'SC', 'ST']].sum()
if 'Total (36 States/UT\'s)' in caste_by_state.index:
    caste_by_state.drop('Total (36 States/UT\'s)', inplace=True)
caste_by_state_top15 = caste_by_state.loc[top_15_states_index]

plt.figure(figsize=(12, 10))
sns.heatmap(
    caste_by_state_top15,
    cmap="YlGnBu",
    annot=True,
    fmt="d",
    linewidths=.5
)

plt.title('Heatmap of Caste-Wise Registrations in Top 15 States/UTs', fontsize=16)
plt.xlabel('Caste Category', fontsize=12)
plt.ylabel('State / UT', fontsize=12)
plt.show()
```


    
![png](output_17_0.png)
    



    
![png](output_17_1.png)
    



    
![png](output_17_2.png)
    



```python

```


## Geographic Disparity Analysis

### Objective
This task looks at differences in how Tele-Law services are used across India. It focuses on variations by state, union territory, and district. The analysis normalizes the data by the number of Common Service Centers (CSCs) to consider regional differences in infrastructure. It assesses fairness and effectiveness in delivering these services.

### Methodology
- **Data Source**: District-wise Tele-Law case registration and advice-enabled data, sourced from https://www.data.gov.in/resource/district-wise-tele-law-case-registration-and-advice-enabled-data-fy-2021-22-2024-25.
- **Technology**: IBM Cloud Lite services and Python libraries (pandas, ibm-boto3, matplotlib).
- **Approach**: The dataset was loaded from IBM Cloud Object Storage, deduplicated by 'Districts' and 'States/UT\'s', and total registrations were aggregated by 'States/UT\'s' and 'Districts', with normalization by 'No. of CSCs'.

### Results
- **Top 10 States/UTs by Total Registrations**:
  - Total(36 States/UTs): 1,02,62,591
  - Uttar Pradesh: 18,50,750
  - Madhya Pradesh: 1,083,427
  - Maharashtra: 7,99,196
  - Jammu and Kashmir: 6,54,383
  - Rajasthan: 6,49,493
  - Bihar: 554,909
  - Chhattisgarh: 5,01,152
  - Jharkhand: 4,68,385
  - Gujarat: 4,32,870
****
- **Bottom 10 Districts by Total Registrations**:
  - SarangarhBilaigarh: 0
  - Pandhurna: 0
  - Kangpokpi: 0
  - KhairgarhChhuikhadanGandai: 0
  - Lower Siang: 0
  - Maihar: 0
  - Shi Yomi: 0
  - Chumoukedima: 0
  - Kamle: 0
  - Shamator: 0
****
- **Top 10 States/UTs by Registrations per CSC**:
  - Delhi: 950.727273
  - Chandigarh: 510.583333
  - Dadra and Nagar Haveli & Daman & Diu: 487.000000
  - Lakshadweep: 261.400000
  - Dadra And Nagar Haveli & Daman & Diu: 185.548485
  - Jammu and Kashmir: 160.179697
  - Andaman and Nicobar: 121.082767
  - Assam: 108.277441
  - Jharkhand: 103.179872
  - Tripura: 80.164737

### Interpretation
The state and union territory analysis shows that Uttar Pradesh leads with 18,50,750 registrations. This brings the total to 1,02,62,591 across all 36 states and union territories after removing duplicates. However, 22 districts report zero registrations, even though they have non-zero Common Service Center (CSC) counts. For example,Kamle has 57 CSCs, and Siang has 78.This suggests possible underuse or problems with data reporting. When looking at CSC-normalized data, Delhi has 950.73 registrations per CSC, and Chandigarh has 510.58. These numbers indicate they provide services effectively. In contrast, the lower rates in states with zero registrations, such as Arunachal Pradesh, may point to gaps in outreach.
## ___________________________________________________________________________________________________________________________________________________________________


```python

```

# Final Review and Consolidation
## Summary of Findings
- **Gender-wise**: Males (2,48,62,532) significantly outnumber Females (1,59,56,220), indicating a gender access gap.
- **Caste-wise**: OBC (1,29,31,124) and SC (1,29,21,364) lead, while ST (54,86,646) lags, suggesting underrepresentation.
- **Geographic**: Uttar Pradesh (18,50,750) dominates state totals, but 22 districts report zero registrations despite CSCs.

## Overall Interpretation
The analysis shows differences in gender, caste, and geographic access to Tele-Law services. Low participation from women and scheduled tribes, along with districts that have no registrations, highlight issues with outreach and data.

## Conclusion
This project highlights the need for inclusive strategies to enhance Tele-Law utilization across India.


```python

```
